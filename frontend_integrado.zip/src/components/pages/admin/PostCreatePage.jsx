import React from 'react';
import PostForm from '../components/PostForm';

function PostCreatePage() {
  return (
    <div>
      {/* O título "Criar Novo Post" já está dentro do PostForm */}
      <PostForm />
    </div>
  );
}

export default PostCreatePage;

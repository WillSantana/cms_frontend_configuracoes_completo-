import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../../context/AuthContext'; // ✅ Importa o contexto de autenticação
const DashboardPage = () => {
    const { user, logout } = useAuth(); // ✅ Usa o contexto
    const [posts, setPosts] = useState([]);
    const [loading, setLoading] = useState(true);
    const [erro, setErro] = useState('');
    const navigate = useNavigate();
    useEffect(() => {
        const fetchData = async () => {
            try {
                // Verifica o usuário logado
                const userRes = await fetch('http://localhost:3001/me', {
                    credentials: 'include',
                });
                if (!userRes.ok) {
                    navigate('/login');
                    return;
                }
                // Busca os posts
                const postsRes = await fetch('http://localhost:3001/api/posts', {
                    credentials: 'include',
                });
                if (!postsRes.ok) {
                    const errorData = await postsRes.json();
                    setErro(errorData.error || 'Erro ao buscar posts');
                }
                else {
                    const postsData = await postsRes.json();
                    setPosts(postsData);
                }
            }
            catch (err) {
                console.error('Erro geral:', err);
                setErro('Erro ao conectar com o servidor');
            }
            finally {
                setLoading(false);
            }
        };
        fetchData();
    }, [navigate]);
    if (loading)
        return _jsx("p", { className: "text-center mt-10", children: "Carregando..." });
    return (_jsxs("div", { className: "flex h-screen bg-gray-100", children: [_jsxs("aside", { className: "w-64 bg-white shadow-lg p-6", children: [_jsx("h2", { className: "text-xl font-bold mb-6", children: "CMS Menu" }), _jsxs("ul", { className: "space-y-3", children: [_jsx("li", { children: _jsx("a", { href: "#", className: "text-blue-600 hover:underline", children: "Painel" }) }), _jsx("li", { children: _jsx("a", { href: "#", className: "hover:underline", children: "Postagens" }) }), _jsx("li", { children: _jsx("a", { href: "#", className: "hover:underline", children: "Usu\u00E1rios" }) }), _jsx("li", { children: _jsx("a", { href: "#", className: "hover:underline", children: "Configura\u00E7\u00F5es" }) })] })] }), _jsxs("main", { className: "flex-1 p-8 overflow-auto", children: [_jsxs("div", { className: "flex justify-between items-center mb-8", children: [_jsxs("h1", { className: "text-3xl font-bold", children: ["Bem-vindo, ", user?.email || 'Usuário', " \uD83D\uDC4B"] }), _jsx("button", { onClick: logout, className: "bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700", children: "Sair" })] }), _jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-3 gap-6 mb-8", children: [_jsxs("div", { className: "bg-white p-6 rounded shadow", children: [_jsx("h2", { className: "text-xl font-semibold", children: "Postagens" }), _jsx("p", { className: "text-3xl font-bold mt-2", children: posts.length })] }), _jsxs("div", { className: "bg-white p-6 rounded shadow", children: [_jsx("h2", { className: "text-xl font-semibold", children: "Usu\u00E1rios" }), _jsx("p", { className: "text-3xl font-bold mt-2", children: "1" })] }), _jsxs("div", { className: "bg-white p-6 rounded shadow", children: [_jsx("h2", { className: "text-xl font-semibold", children: "Configura\u00E7\u00F5es" }), _jsx("p", { className: "text-sm text-gray-500 mt-2", children: "Configura\u00E7\u00F5es b\u00E1sicas do CMS ativas." })] })] }), _jsxs("div", { className: "bg-white p-6 rounded shadow", children: [_jsx("h2", { className: "text-xl font-semibold mb-4", children: "Lista de Postagens" }), erro && _jsx("p", { className: "text-red-500 mb-4", children: erro }), posts.length === 0 ? (_jsx("p", { className: "text-gray-600", children: "Nenhuma postagem encontrada." })) : (_jsxs("table", { className: "w-full text-sm border", children: [_jsx("thead", { children: _jsxs("tr", { className: "bg-gray-100", children: [_jsx("th", { className: "p-2 text-left", children: "T\u00EDtulo" }), _jsx("th", { className: "p-2 text-left", children: "Slug" }), _jsx("th", { className: "p-2 text-left", children: "Status" }), _jsx("th", { className: "p-2 text-left", children: "Autor" }), _jsx("th", { className: "p-2 text-left", children: "Criado em" })] }) }), _jsx("tbody", { children: posts.map((post) => (_jsxs("tr", { className: "border-b hover:bg-gray-50", children: [_jsx("td", { className: "p-2 font-medium", children: post.titulo }), _jsx("td", { className: "p-2 text-gray-500", children: post.slug }), _jsx("td", { className: "p-2", children: _jsx("span", { className: `inline-block px-2 py-1 text-xs rounded ${post.status === 'publicado'
                                                            ? 'bg-green-100 text-green-700'
                                                            : 'bg-yellow-100 text-yellow-700'}`, children: post.status }) }), _jsx("td", { className: "p-2", children: post.autor?.username || 'Desconhecido' }), _jsx("td", { className: "p-2 text-gray-500", children: new Date(post.createdAt).toLocaleDateString('pt-BR') })] }, post._id))) })] }))] })] })] }));
};
export default DashboardPage;

import { jsx as _jsx } from "react/jsx-runtime";
import { createContext, useContext, useState, useEffect, } from 'react';
import api from '../services/api';
const AuthContext = createContext(undefined);
export const AuthProvider = ({ children }) => {
    const [user, setUser] = useState(null);
    const [authToken, setAuthToken] = useState(localStorage.getItem('authToken'));
    const [loading, setLoading] = useState(true);
    const isAuthenticated = !!authToken;
    useEffect(() => {
        const initializeAuth = async () => {
            if (authToken) {
                api.defaults.headers.common['Authorization'] = `Bearer ${authToken}`;
                try {
                    const userRes = await api.get('/users/me/');
                    setUser(userRes.data);
                }
                catch (err) {
                    console.error('Erro ao carregar usuário:', err);
                    logout(); // Token inválido
                }
            }
            setLoading(false);
        };
        initializeAuth();
    }, [authToken]);
    const login = async (email, password) => {
        try {
            setLoading(true);
            const response = await api.post('/auth/login/', { email, password });
            const { access } = response.data;
            setAuthToken(access);
            localStorage.setItem('authToken', access);
            api.defaults.headers.common['Authorization'] = `Bearer ${access}`;
            const userRes = await api.get('/users/me/');
            setUser(userRes.data);
            return { success: true };
        }
        catch (error) {
            console.error('Erro ao fazer login:', error);
            return {
                success: false,
                message: error?.response?.data?.detail || 'Erro ao fazer login',
            };
        }
        finally {
            setLoading(false);
        }
    };
    const register = async (email, password) => {
        try {
            setLoading(true);
            await api.post('/users/', { email, password }); // corrigido aqui
            return { success: true };
        }
        catch (error) {
            console.error('Erro ao registrar:', error);
            return {
                success: false,
                message: error?.response?.data?.detail || 'Erro ao registrar',
            };
        }
        finally {
            setLoading(false);
        }
    };
    const logout = () => {
        setUser(null);
        setAuthToken(null);
        localStorage.removeItem('authToken');
        delete api.defaults.headers.common['Authorization'];
    };
    return (_jsx(AuthContext.Provider, { value: {
            user,
            loading,
            authToken,
            isAuthenticated,
            login,
            register,
            logout,
        }, children: children }));
};
export const useAuth = () => {
    const context = useContext(AuthContext);
    if (!context) {
        throw new Error('useAuth deve ser usado dentro de um AuthProvider');
    }
    return context;
};
